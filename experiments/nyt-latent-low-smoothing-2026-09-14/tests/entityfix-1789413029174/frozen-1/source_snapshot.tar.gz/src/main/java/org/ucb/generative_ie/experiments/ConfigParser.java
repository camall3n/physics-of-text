package org.ucb.generative_ie.experiments;

import com.google.gson.Gson;
import java.io.FileNotFoundException;
import java.io.FileReader;

/**
 * The configuration of the model
 */
public final class ConfigParser {
    public int numEnts;
    public int numRels;
    public double alpha;
    public double beta;
    public double sparsity;
    public int numIterations;
    public int maxRels;        // relation pool size (0: numRels); numRels is then the prior mean of relations in use
    public double sparsityA;   // Beta(a, b) prior on per-relation sparsity (0: constant sparsity)
    public double sparsityB;
    public double entityFraction = 0.2;   // share of numIterations spent in the entity phase (0 skips it)
    public int stepsPerIteration = 50;    // MCMC moves per recorded iteration
    
    public ConfigParser(String configFile){
        FileReader reader;
        try {
            reader = new FileReader(configFile);
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
        
        load(reader);
    }
    
    public void load(FileReader reader) {
        Gson configGson = new Gson();
        Configuration config = configGson.fromJson(reader, Configuration.class);
        
        this.numEnts = config.numEnts;
        this.numRels =  config.numRels;
        this.alpha = config.alpha;
        this.beta = config.beta;
        this.sparsity = config.sparsity;
        this.numIterations = config.numIterations;
        this.maxRels = config.maxRels;
        this.sparsityA = config.sparsityA;
        this.sparsityB = config.sparsityB;
        if (config.entityFraction != null) {
            this.entityFraction = config.entityFraction;
        }
        if (config.stepsPerIteration != null) {
            this.stepsPerIteration = config.stepsPerIteration;
        }
    }
    
    public void showConfig() {
        StringBuilder output = new StringBuilder();
        
        output.append("The configuration:\n");
        output.append(String.format("  Number of Entity: %d\n", this.numEnts));
        output.append(String.format("  Number of Relations: %d\n", this.numRels));
        output.append(String.format("  Prior for Entities: %f\n", this.alpha));
        output.append(String.format("  Prior for Relation: %f\n", this.beta));
        output.append(String.format("  Sparsity of facts: %f\n", this.sparsity));
        output.append(String.format("  Number of Iterations: %d\n", this.numIterations));
        output.append(String.format("  Relation pool size: %d\n", this.maxRels > 0 ? this.maxRels : this.numRels));
        if (this.sparsityA > 0) {
            output.append(String.format("  Sparsity prior: Beta(%f, %f)\n", this.sparsityA, this.sparsityB));
        }
        output.append(String.format("  Entity phase fraction: %.2f, moves per iteration: %d\n", this.entityFraction, this.stepsPerIteration));
        
        output.append("================================================================\n");
        
        System.out.print(output);
    }
    
    class Configuration {
        public int numEnts;
        public int numRels;
        public int numIterations;
        public double alpha;
        public double beta;
        public double sparsity;
        public int maxRels;
        public double sparsityA;
        public double sparsityB;
        public Double entityFraction;    // null when absent
        public Integer stepsPerIteration;
    }
}
