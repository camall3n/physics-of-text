import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {ROOT,json,fmt,sha,stable,within} from './census_lib.mjs';
import {loadCatalogue,predicateHash,dictionaryHash} from './coverage_lib.mjs';
export function declarePredicate(folder,{relation,predicate_id,rationale,reviewer,declared_at=new Date().toISOString(),supporting_path_indices=[],competing_meanings=[],scope_limitations=[],argument_roles_inspected=true,complete_dictionary_read=true}){
 const out=within(path.resolve(folder)),cases=json(path.join(out,'cases.json')),r=cases.relations.find(r=>r.relation===relation);assert(r,'Relation outside selected prefix');
 assert(typeof rationale==='string'&&rationale.trim(),'Dictionary-selection rationale required');assert(typeof reviewer==='string'&&reviewer.trim(),'Reviewer required');
 const p=loadCatalogue().get(predicate_id);assert(p,'Predicate must be approved in the append-only catalogue first');for(const k of ['label','definition','scope_notes'])assert(typeof p[k]==='string'&&p[k].trim(),`Missing predicate ${k}`);
 const annFile=path.join(out,'annotations',relation+'.json'),declarationFile=path.join(out,'declarations',relation+'.json'),a=json(annFile);
 if(fs.existsSync(declarationFile)){const old=json(declarationFile);assert.equal(old.predicate_id,predicate_id,'Frozen predicate cannot change');assert.equal(old.predicate_hash,predicateHash(p),'Frozen predicate content changed');assert.equal(old.dictionary_sha256,dictionaryHash(r),'Frozen dictionary changed');return old;}
 assert(a.facts.length===r.facts.length&&a.facts.every(f=>!f.judgment),'Declare before any fact judgments');
 const human=json(path.join(out,'human_review.json'));assert(!human.overrides.some(f=>f.judgment&&r.facts.some(c=>c.case_id===f.case_id)),'Declare before any human judgments');
 const blankRaw=fs.readFileSync(annFile,'utf8'),blankFile=relation+'.before_grading.json';stable(path.join(out,'declarations',blankFile),blankRaw);
 assert(complete_dictionary_read&&argument_roles_inspected,'Full dictionary and ordered roles must be inspected');assert(Array.isArray(supporting_path_indices)&&supporting_path_indices.every(i=>Number.isInteger(i)&&i>=0&&i<r.paths.length),'Invalid supporting dictionary index');
 const d={relation,predicate_id,predicate_version:p.version??1,predicate_hash:predicateHash(p),predicate:p,dictionary_sha256:dictionaryHash(r),kind:'declared_before_case_grading',rationale,reviewer,declared_at,complete_dictionary_read,argument_roles_inspected,supporting_path_indices,competing_meanings,scope_limitations,source_map_sha256:cases.metadata.source_sha256,pregrading_annotation_file:blankFile,pregrading_annotation_sha256:sha(blankRaw)};
 stable(declarationFile,fmt(d));Object.assign(a,{predicate_id,label:p.label,definition:p.definition,scope_notes:p.scope_notes,predicate_hash:d.predicate_hash,predicate_version:d.predicate_version,predicate_declaration_sha256:sha(fmt(d))});fs.writeFileSync(annFile,fmt(a));return d;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const [audit,file]=process.argv.slice(2);assert(audit&&file,'Usage: node declare_predicate.mjs AUDIT DECLARATIONS.json; JSON is {declarations:[{relation,predicate_id,rationale,reviewer}]}');
 for(const d of json(path.resolve(file)).declarations)declarePredicate(path.join(ROOT,'census',audit),d);
 console.log('Declared '+json(path.resolve(file)).declarations.length+' predicates for '+audit);
}
