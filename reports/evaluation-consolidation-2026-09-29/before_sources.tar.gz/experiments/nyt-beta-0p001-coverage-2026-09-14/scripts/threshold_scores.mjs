import assert from 'node:assert/strict';
export function scoreFacts(facts){let S=0,E=0,A=0;for(const f of facts){if(f.judgment==='supported')S++;else if(f.judgment==='incorrect')E++;else if(f.judgment==='ambiguous')A++;else throw Error('Unreviewed fact: '+f.case_id);}const N=facts.length,unresolved=facts.filter(f=>f.predicate_id==='unresolved_relation');return {N,S,E,A,unresolved_predicate_facts:unresolved.length,unresolved_predicate_relations:new Set(unresolved.map(f=>f.relation)).size,lower:N?S/N:null,upper:N?(S+A)/N:null};}
export function scoreCoverage(result){
 const baseK=result.coverage.reference_top20.k,base=scoreFacts(result.facts.filter(f=>f.relation_rank<=baseK));
 for(const key of ['N','S','E','A'])assert.equal(base[key],result.coverage.reference_top20.counts[key],'Prior top20 scores changed');
 let previousK=baseK;const thresholds=result.coverage.targets.map(t=>{assert(t.k>=previousK,'Thresholds must nest above the baseline');const facts=result.facts.filter(f=>f.relation_rank<=t.k),added=result.facts.filter(f=>f.relation_rank>previousK&&f.relation_rank<=t.k),counts=scoreFacts(facts);assert.equal(counts.N,t.N,'Threshold fact denominator differs');const marginal={from_exclusive_rank:previousK,to_inclusive_rank:t.k,...scoreFacts(added)};previousK=t.k;return {...t,...counts,marginal};});
 return {reference_top20:{k:baseK,rows:result.coverage.reference_top20.rows,achieved_coverage:result.coverage.reference_top20.rows/result.metadata.corpus_sentences,...base},thresholds};
}
