// Diagnostic only. Never assigns, changes, or propagates semantic judgments.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {ROOT,json,fmt,sha} from './census_lib.mjs';
import {PRIOR_ROOT,loadCatalogue,predicateHash} from './coverage_lib.mjs';
const valid=new Set(['supported','incorrect','ambiguous']);

export function semanticSignature(predicate,c){
 // Repeated observations and run-local numeric IDs do not change the semantic
 // evidence set. Equality of the two argument IDs DOES affect local identity.
 const evidence=[...new Set(c.evidence.map(e=>JSON.stringify([e.arg1,e.arg2,e.dependency_path])))].sort();
 return JSON.stringify([predicateHash(predicate),c.entity1===c.entity2,evidence]);
}
export function effectiveJudgment(primary,override){
 if(override?.judgment){assert(valid.has(override.judgment),'Invalid human override');return override;}
 return primary?.judgment&&!primary.provisional?primary:null;
}
export function findDisagreements(records){
 const groups=new Map();for(const r of records){if(!groups.has(r.signature))groups.set(r.signature,[]);groups.get(r.signature).push(r);}
 const disagreements=[];let repeated=0;
 for(const [signature,cases]of groups){
  if(cases.length>1)repeated++;
  if(!cases.some(c=>c.origin==='current')||new Set(cases.map(c=>c.judgment)).size<2)continue;
  const [predicate_hash,self_entity,evidence]=JSON.parse(signature);
  disagreements.push({signature_sha256:sha(signature),predicate_id:cases[0].predicate_id,predicate_hash,self_entity,evidence:evidence.map(JSON.parse),cases:cases.map(({signature,...c})=>c)});
 }
 return {distinct_signatures:groups.size,repeated_signatures:repeated,disagreement_count:disagreements.length,disagreements};
}
export function checkSemanticConsistency({includePrior=true}={}){
 const catalogue=loadCatalogue(),records=[],currentKeys=new Set();let reviewed=0,unreviewed=0,priorReferences=0,priorSkipped=0;
 for(const a of json(path.join(ROOT,'census_manifest.json')).audits){
  const dir=path.join(ROOT,a.folder),cases=json(path.join(dir,'cases.json')),human=json(path.join(dir,'human_review.json'));
  const overrides=new Map(human.overrides.filter(o=>o.judgment).map(o=>[o.case_id,o]));
  for(const r of cases.relations){
   const ann=json(path.join(dir,'annotations',r.relation+'.json')),p=catalogue.get(ann.predicate_id),labels=new Map(ann.facts.map(f=>[f.case_id,f]));
   for(const c of r.facts){
    currentKeys.add(cases.metadata.source_sha256+':'+c.case_id);
    const f=effectiveJudgment(labels.get(c.case_id),overrides.get(c.case_id));
    if(!f){unreviewed++;continue;}assert(p,'Undefined current predicate');assert(valid.has(f.judgment),'Invalid current judgment');reviewed++;
    records.push({origin:'current',signature:semanticSignature(p,c),predicate_id:p.id,audit:a.audit_id,relation:r.relation,case_id:c.case_id,judgment:f.judgment,reason:f.reason,evidence_lines:f.evidence_lines,report:path.join(a.folder,'reports',r.relation+'.md')+'#'+c.case_id});
   }
  }
 }
 const main=findDisagreements(records);
 if(includePrior){
  for(const a of json(path.join(PRIOR_ROOT,'census_manifest.json')).audits){
   const file=path.join(PRIOR_ROOT,a.folder,'assessment.json'),priorRaw=fs.readFileSync(file),assessmentHash=sha(priorRaw),prior=JSON.parse(priorRaw),strata=new Map(prior.strata.map(s=>[s.relation,s]));
   for(const c of prior.facts){
    if(currentKeys.has(prior.metadata.source_sha256+':'+c.case_id))continue;
    const p=catalogue.get(c.predicate_id),s=strata.get(c.relation);
    // Only a frozen, identical definition/scope can supply a prior reference.
    if(!p||p.definition!==s.definition||p.scope_notes!==s.scope_notes){priorSkipped++;continue;}
    assert(valid.has(c.judgment),'Invalid preserved reference judgment');priorReferences++;
    records.push({origin:'prior_reference',signature:semanticSignature(p,c),predicate_id:p.id,audit:a.audit_id,relation:c.relation,case_id:c.case_id,judgment:c.judgment,reason:c.reason,evidence_lines:c.evidence_lines,assessment_sha256:assessmentHash,report:path.relative(ROOT,path.join(PRIOR_ROOT,a.folder,'reports',c.relation+'.md'))+'#'+c.case_id});
   }
  }
 }
 const combined=findDisagreements(records),report={method:'Exact complete sets of literal argument names and dependency paths, identical frozen predicate scope, and same-entity-ID status. Duplicate rows and run-local numeric IDs are ignored. Effective human overrides are included. Flag only; every disagreement needs manual review. Prior references are separate and never enter current score denominators.',reviewed,unreviewed,prior_references:priorReferences,prior_nonidentical_scopes_skipped:priorSkipped,current:main,with_prior_references:combined};
 fs.writeFileSync(path.join(ROOT,'analysis/semantic_consistency.json'),fmt(report));
 const md=['# Exact-evidence semantic consistency','','Diagnostic only: this file does not change annotations or scores. Matching requires the complete literal evidence set, the same frozen predicate, and the same status of entity-ID equality. Repetition of an identical row does not change the evidence set. Human overrides are respected.','','Current reviewed facts: '+reviewed+'; unreviewed: '+unreviewed+'. Current-only disagreements: '+main.disagreement_count+'. Disagreements including separately identified preserved references: '+combined.disagreement_count+'.','','[Structured diagnostic](semantic_consistency.json)','','Prior references do not enter any coverage or precision denominator. An identical evidence set is a consistency flag, not permission to copy a judgment automatically.',''];
 for(const [i,g]of combined.disagreements.entries()){
  md.push('## '+(i+1)+'. '+g.predicate_id,'','Signature: '+g.signature_sha256,'','Complete distinct evidence:','',...g.evidence.map(([x,y,p])=>'- '+JSON.stringify(x)+' → '+JSON.stringify(y)+' — `'+p.replaceAll('`','\\`')+'`'),'');
  for(const c of g.cases)md.push('- **'+c.judgment+'** ['+c.audit+'/'+c.case_id+'](../'+c.report+') ('+c.origin+'): '+c.reason);
  md.push('');
 }
 fs.writeFileSync(path.join(ROOT,'analysis/semantic_consistency.md'),md.join('\n'));return report;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const r=checkSemanticConsistency({includePrior:!process.argv.includes('--current-only')});console.log(JSON.stringify({reviewed:r.reviewed,unreviewed:r.unreviewed,current_disagreements:r.current.disagreement_count,with_prior_disagreements:r.with_prior_references.disagreement_count}));
}
