// Verify complete published views against the strictly validated assessments.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {ROOT,json,fmt,sha} from './census_lib.mjs';
import {validateAudit} from './report_censuses.mjs';
const comparison=json(path.join(ROOT,'comparison.json')),runs=[];
assert.equal(comparison.complete,true);assert.equal(comparison.runs.length,4);
for(const run of comparison.runs){
 const dir=path.join(ROOT,path.dirname(run.assessment)),validated=validateAudit(dir),saved=json(path.join(dir,'assessment.json'));
 assert.deepEqual(saved.facts,validated.facts,'Saved full assessment differs from final annotations');
 assert.deepEqual(saved.counts,validated.counts);assert.deepEqual(run.maximum_population,validated.counts);
 for(const c of validated.facts){const md=fs.readFileSync(path.join(dir,'reports',c.relation+'.md'),'utf8');assert(md.includes('### '+c.case_id),'Missing evaluated case heading');assert(md.includes('**Judgment: '+c.judgment+'**'),'Missing judgment rendering');}
 const cells=[];
 for(const t of run.thresholds){
  const stem='coverage_'+Math.round(t.target*100),file=path.join(dir,stem+'.json'),d=json(file),md=fs.readFileSync(path.join(dir,stem+'.md'),'utf8');
  const expectedFacts=validated.facts.filter(f=>f.relation_rank<=t.k),expectedStrata=validated.strata.filter(r=>r.rank<=t.k);
  assert.deepEqual(d.facts,expectedFacts,'Cutoff changed/omitted fact evidence or grade');assert.deepEqual(d.strata,expectedStrata,'Cutoff changed/omitted relation');assert.equal(d.facts.length,t.N);assert.equal(d.strata.length,t.k);assert.deepEqual(d.counts,{N:t.N,S:t.S,E:t.E,A:t.A});
  const linked=[...new Set([...md.matchAll(/\(reports\/(rel_\d+)\.md\)/g)].map(m=>m[1]))];assert.deepEqual(linked,expectedStrata.map(r=>r.relation),'Markdown cutoff has missing/foreign ranked links');
  for(const f of expectedFacts.filter(f=>f.judgment==='ambiguous'))assert(md.includes('#'+f.case_id+')'),'Missing selected review question');
  for(const f of validated.facts.filter(f=>f.relation_rank>t.k))assert(!md.includes('#'+f.case_id+')'),'Foreign review question from later cutoff');
  cells.push({target:t.target,k:t.k,N:t.N,S:t.S,E:t.E,A:t.A,json_sha256:sha(fs.readFileSync(file)),markdown_sha256:sha(md)});
 }
 const readme=fs.readFileSync(path.join(dir,'README.md'),'utf8');assert(readme.includes('additional facts completely reviewed'));assert(!readme.includes('require complete review'));
 runs.push({audit_id:run.audit_id,counts:validated.counts,old_top20_exactly_preserved:true,evaluated_relation_reports:validated.strata.length,cutoffs:cells});
}
const log=fs.readFileSync(path.join(ROOT,'analysis/pipeline_tests.tap'),'utf8'),testCounts=Object.fromEntries([...log.matchAll(/^# (tests|pass|fail|cancelled|skipped) (\d+)$/gm)].map(m=>[m[1],Number(m[2])])) ;
assert(testCounts.tests>0);assert.equal(testCounts.fail,0);assert.equal(testCounts.pass,testCounts.tests);
const semantic=json(path.join(ROOT,'analysis/semantic_consistency.json'));
assert.equal(semantic.unreviewed,0);assert.equal(semantic.reviewed,8488);assert.equal(semantic.current.disagreement_count,0);assert.equal(semantic.with_prior_references.disagreement_count,0);
const report={complete:true,current_fact_population:8488,cutoff_views:runs.reduce((n,r)=>n+r.cutoffs.length,0),relation_reports:runs.reduce((n,r)=>n+r.evaluated_relation_reports,0),tests:testCounts,tests_log:'pipeline_tests.tap',tests_log_sha256:sha(log),exact_evidence_consistency:{reviewed:semantic.reviewed,unreviewed:semantic.unreviewed,current_disagreements:semantic.current.disagreement_count,with_prior_disagreements:semantic.with_prior_references.disagreement_count},runs};
assert.equal(report.cutoff_views,20);assert.equal(report.relation_reports,1144);fs.writeFileSync(path.join(ROOT,'analysis/final_pipeline_validation.json'),fmt(report));console.log(JSON.stringify({complete:report.complete,N:report.current_fact_population,views:report.cutoff_views,relations:report.relation_reports,tests:report.tests}));
