import fs from 'node:fs';
import path from 'node:path';
import {ROOT,json,fmt,stable} from './census_lib.mjs';
import {prepareCoverage,TARGETS} from './coverage_lib.mjs';
const audits=json(path.join(ROOT,'source_runs.json')).runs.map(entry=>prepareCoverage(entry));
stable(path.join(ROOT,'census_manifest.json'),fmt({schema_version:1,mode:'sentence_rows',targets:TARGETS,selection:'Smallest ranked prefix reaching each requested fraction of input rows',audits}));
console.log(JSON.stringify(audits.map(a=>({audit_id:a.audit_id,N:a.population_facts,k:a.relations,inherited:a.inherited_exact_cases})),null,2));
