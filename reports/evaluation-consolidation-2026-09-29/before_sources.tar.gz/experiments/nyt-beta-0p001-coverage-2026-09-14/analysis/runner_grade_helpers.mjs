import {record,seq} from '../scripts/manual_helpers.mjs';
export {seq};
export const R=(relation,groups,options={})=>record('audit_9c88162c7b22',relation,groups.map(([indices,label,...rest])=>[indices,{S:'supported',E:'incorrect',A:'ambiguous'}[label],...rest]),{reviewer:'runner',...options});
