import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {parseMap} from '../../nyt-complete-evaluation-2026-09-14/scripts/parse_map.mjs';
const base=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const repo=path.resolve(base,'../..');
const runs=JSON.parse(fs.readFileSync(path.join(base,'source_runs.json'))).runs;
for(const run of runs){
 const parsed=parseMap(fs.readFileSync(path.join(repo,run.source),'utf8'));
 const metadata={audit_id:run.audit_id,label:run.label,source:run.source,source_sha256:run.source_sha256,total_rows:parsed.sentence_count,total_facts:parsed.fact_count,total_relations:parsed.relation_count};
 const records=parsed.relations.map(r=>({rank:r.rank,relation:r.relation,sentence_count:r.sentence_count,facts:r.facts.length,paths:r.paths}));
 fs.writeFileSync(path.join(base,'analysis',run.audit_id+'_dictionaries.json'),JSON.stringify({metadata,relations:records},null,2)+'\n');
 fs.writeFileSync(path.join(base,'analysis',run.audit_id+'_dictionaries.md'),`# Full ranked relation dictionaries: ${run.audit_id}\n\nRead-only extraction of every supplied dictionary path and its row count. No semantic labels or fact grades are generated. Source: \`${run.source}\`.\n\n`+records.map(r=>`## Rank ${r.rank}: ${r.relation} (${r.sentence_count} rows; ${r.facts} facts)\n\n`+r.paths.map((p,i)=>`- P${i} × ${p.count}: \`${p.value}\``).join('\n')).join('\n\n')+'\n');
 console.log(run.audit_id,parsed.relation_count,parsed.relations.reduce((n,r)=>n+r.paths.length,0),'paths');
}
