import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {ROOT,REPO,json,sha,fmt,pct,esc,within,censusFromRaw,factMarkdown,dictionaryMarkdown} from './census_lib.mjs';
import {writePriorComparisons} from './prior_comparisons.mjs';
const allowed=new Set(['supported','incorrect','ambiguous']);
const nonempty=x=>typeof x==='string'&&x.trim().length>0;
function validateJudgment(j,c,{human=false}={}){
 assert(allowed.has(j.judgment),`Missing/invalid judgment for ${c.case_id}`);assert(nonempty(j.reason),`Missing reason for ${c.case_id}`);
 assert(Array.isArray(j.evidence_lines)&&j.evidence_lines.length,`Missing citations for ${c.case_id}`);
 assert.equal(new Set(j.evidence_lines).size,j.evidence_lines.length,`Duplicate citations for ${c.case_id}`);
 const valid=new Set(c.evidence.map(e=>e.line));for(const line of j.evidence_lines)assert(Number.isInteger(line)&&valid.has(line),`Foreign/invalid citation ${line} for ${c.case_id}`);
 assert(Array.isArray(j.issue_tags)&&j.issue_tags.every(t=>typeof t==='string'),`Invalid issue tags for ${c.case_id}`);
 assert(typeof j.reviewer_question==='string',`Missing question field for ${c.case_id}`);
 if(j.judgment==='ambiguous')assert(nonempty(j.reviewer_question),`Ambiguous case lacks specific question: ${c.case_id}`);
 if(human)assert(nonempty(j.reviewer),`Human override lacks reviewer: ${c.case_id}`);
}
export function validateAudit(folder,{requirePredicateId=true,catalogueIds=null}={}){
 const absolute=within(path.resolve(folder));const raw=fs.readFileSync(path.join(absolute,'raw_map.tsv'),'utf8');
 const d=json(path.join(absolute,'cases.json')),source=json(path.join(absolute,'source.json'));
 assert.equal(sha(raw),d.metadata.source_sha256,'Copied MAP source hash changed');assert.equal(source.source_sha256,d.metadata.source_sha256,'Source manifest hash mismatch');
 assert.equal(sha(fs.readFileSync(path.join(absolute,'cases.json'))),source.cases_sha256,'Cases file hash changed');
 assert.equal(sha(fs.readFileSync(path.resolve(REPO,source.source))),source.source_sha256,'Original MAP source changed');
 const expected=censusFromRaw(raw,{topRelations:d.metadata.top_relations_requested});
 for(const [key,value]of Object.entries(expected.metadata))assert.deepEqual(d.metadata[key],value,`Census metadata mismatch: ${key}`);
 assert.deepEqual(d.relations,expected.relations,'Census incomplete, reordered or evidence changed');assert.equal(d.metadata.audit_id,source.audit_id,'Audit ID mismatch');
 for(const [file,hash] of Object.entries(source.prior_annotation_hashes??{}))assert.equal(sha(fs.readFileSync(path.join(absolute,'prior_annotations',file))),hash,'Prior annotation snapshot changed');
 if(fs.existsSync(path.join(absolute,'prior_human_review.json')))assert.equal(sha(fs.readFileSync(path.join(absolute,'prior_human_review.json'))),fs.readFileSync(path.join(absolute,'prior_human_review.sha256'),'utf8').trim(),'Prior human review snapshot changed');
 if(source.prior_cases_sha256)assert.equal(sha(fs.readFileSync(path.join(absolute,'prior_cases.json'))),source.prior_cases_sha256,'Prior cases snapshot changed');
 let catalogue=null,assignment=null;
 if(absolute.startsWith(path.join(ROOT,'census')+path.sep)&&fs.existsSync(path.join(ROOT,'analysis/predicate_catalogue.json'))){const catRaw=fs.readFileSync(path.join(ROOT,'analysis/predicate_catalogue.json'));catalogue=new Map(JSON.parse(catRaw).predicates.map(p=>[p.id,p]));const mapping=json(path.join(ROOT,'analysis/relation_assignments.json'));assert.equal(mapping.catalogue_sha256,sha(catRaw),'Catalogue assignment hash mismatch');assignment=new Map(mapping.assignments.filter(a=>a.audit_id===source.audit_id).map(a=>[a.relation,a.predicate_id]));}
 const allCases=new Map(d.relations.flatMap(r=>r.facts.map(c=>[c.case_id,c]))),human=json(path.join(absolute,'human_review.json'));
 assert.equal(human.source_sha256,source.source_sha256,'Human override source hash mismatch');assert(Array.isArray(human.overrides),'Overrides must be an array');
 const overrides=new Map(),seenHuman=new Set();for(const o of human.overrides){assert(allCases.has(o.case_id),`Foreign human case: ${o.case_id}`);assert(!seenHuman.has(o.case_id),`Duplicate human case: ${o.case_id}`);seenHuman.add(o.case_id);if(o.judgment){validateJudgment(o,allCases.get(o.case_id),{human:true});overrides.set(o.case_id,o);}else assert(o.judgment===''||o.judgment==null,'Invalid blank override');}
 const names=fs.readdirSync(path.join(absolute,'annotations')).filter(f=>f.endsWith('.json')).sort();assert.deepEqual(names,d.relations.map(r=>r.relation+'.json').sort(),'Missing or foreign relation annotation file');
 const strata=[],facts=[];let totalS=0,totalE=0,totalA=0,totalOverrides=0;
 for(const r of d.relations){const a=json(path.join(absolute,'annotations',r.relation+'.json'));assert.equal(a.relation,r.relation,'Wrong relation annotation');
  assert(nonempty(a.label)&&nonempty(a.definition)&&nonempty(a.scope_notes),`Undefined predicate for ${r.relation}`);
  if(catalogue){assert(catalogue.has(a.predicate_id),`Undefined catalogue predicate: ${a.predicate_id}`);assert.equal(a.predicate_id,assignment.get(r.relation),'Relation predicate differs from frozen assignment');const p=catalogue.get(a.predicate_id);for(const k of ['label','definition','scope_notes'])assert.equal(a[k],p[k],`Noncanonical predicate ${k}: ${r.relation}`);}
  if(requirePredicateId)assert(nonempty(a.predicate_id),`Missing predicate_id for ${r.relation}`);if(catalogueIds)assert(catalogueIds.has(a.predicate_id),`Undefined catalogue predicate ${a.predicate_id}`);
  assert(Array.isArray(a.facts));const seen=new Set();const expectedIds=new Set(r.facts.map(c=>c.case_id));for(const f of a.facts){assert(expectedIds.has(f.case_id),`Foreign case in ${r.relation}: ${f.case_id}`);assert(!seen.has(f.case_id),`Duplicate case: ${f.case_id}`);seen.add(f.case_id);}assert.equal(seen.size,r.facts.length,`Missing cases in ${r.relation}`);
  const byId=new Map(a.facts.map(f=>[f.case_id,f]));let S=0,E=0,A=0,H=0;
  for(const c of r.facts){const primary=byId.get(c.case_id),override=overrides.get(c.case_id);if(primary.judgment)validateJudgment(primary,c);if(!override)assert(primary.provisional!==true,`Unconfirmed provisional judgment: ${c.case_id}`);const chosen=override??primary;validateJudgment(chosen,c,{human:!!override});
   if(chosen.judgment==='supported')S++;else if(chosen.judgment==='incorrect')E++;else A++;if(override)H++;
   facts.push({...c,predicate_id:a.predicate_id,label:a.label,judgment:chosen.judgment,reason:chosen.reason,evidence_lines:chosen.evidence_lines,issue_tags:chosen.issue_tags,reviewer_question:chosen.reviewer_question,judgment_source:override?'human_override':'primary',reviewer:chosen.reviewer??chosen.review?.reviewer??a.reviewer??'',primary_judgment:primary,override:override??null});
  }
  const N=r.facts.length;assert.equal(S+E+A,N);strata.push({relation:r.relation,predicate_id:a.predicate_id,label:a.label,definition:a.definition,scope_notes:a.scope_notes,rank:r.rank,rows:r.sentence_count,N,S,E,A,human_overrides:H,lower:S/N,upper:(S+A)/N,decided_precision:S+E?S/(S+E):null,decided_coverage:(S+E)/N});totalS+=S;totalE+=E;totalA+=A;totalOverrides+=H;
 }
 const N=d.metadata.population_facts;assert.equal(facts.length,N);assert.equal(totalS+totalE+totalA,N);
 return {metadata:{...d.metadata,method:'../../METHOD.md',source_manifest:source,census_complete:true,evaluation_unit:'Every expressed ordered latent fact in the selected top relations',limitations:'Exact descriptive census fractions conditional on predicate definitions and judgments; ambiguity endpoints are not confidence intervals. No sampling standard errors or sampling confidence intervals apply. Gold fact recall is unknown.'},counts:{N,S:totalS,E:totalE,A:totalA,human_overrides:totalOverrides},precision:{lower:totalS/N,upper:(totalS+totalA)/N,decided_precision:totalS+totalE?totalS/(totalS+totalE):null,decided_coverage:(totalS+totalE)/N},macro:{lower:strata.reduce((v,s)=>v+s.lower,0)/strata.length,upper:strata.reduce((v,s)=>v+s.upper,0)/strata.length},strata,facts};
}
export function writeAuditReport(folder,options={}){
 const absolute=within(path.resolve(folder));const result=validateAudit(absolute,options);const source=json(path.join(absolute,'cases.json'));
 const reports=path.join(absolute,'reports');fs.mkdirSync(reports,{recursive:true});
 for(const s of result.strata){const r=source.relations.find(r=>r.relation===s.relation),cases=result.facts.filter(c=>c.relation===s.relation);
  const md=[`# ${result.metadata.audit_id} — ${s.relation}: ${s.label}`,'',`Predicate ID: ${s.predicate_id}`,'',s.definition,'',s.scope_notes,'',`Complete census: ${s.S} supported, ${s.E} incorrect, ${s.A} ambiguous; N=${s.N}. Precision ${s.S}/${s.N}=${pct(s.lower)} to ${s.S+s.A}/${s.N}=${pct(s.upper)}.`,'',...dictionaryMarkdown(r),'## Every evaluated fact',''];
  for(const c of cases)md.push(...factMarkdown(c),`**Judgment: ${c.judgment}** (${c.judgment_source}). ${c.reason}`,'',`Cited evidence lines: ${c.evidence_lines.map(n=>`[${n}](../raw_map.tsv:${n})`).join(', ')}.`,'',c.reviewer_question?`**Review question:** ${c.reviewer_question}`:'',c.issue_tags.length?`Issue tags: ${c.issue_tags.join(', ')}`:'','');
  fs.writeFileSync(path.join(reports,s.relation+'.md'),md.join('\n'));
 }
 fs.writeFileSync(path.join(absolute,'assessment.json'),fmt(result));
 const c=result.counts,md=[`# Complete census: ${result.metadata.audit_id}`,'','[Method](../../METHOD.md) · [Structured assessment](assessment.json) · [Editable human overrides](human_review.json)','',`**${c.N}/${c.N} facts evaluated.** ${c.S} supported, ${c.E} incorrect, ${c.A} ambiguous. Exact census precision is **${c.S}/${c.N} = ${pct(result.precision.lower)}** with ambiguity counted incorrect, or **${c.S+c.A}/${c.N} = ${pct(result.precision.upper)}** with ambiguity counted supported.`,'','These are complete-population descriptive fractions for this saved run, conditional on the declared predicates and judgments. They are not confidence limits and do not include reviewer uncertainty, sampler variability or gold-standard recall. No sampling statistics are used.','',`Decided-only precision: ${result.precision.decided_precision===null?'undefined':pct(result.precision.decided_precision)}; decided coverage: ${pct(result.precision.decided_coverage)}. Macro precision (equal relation weights): ${pct(result.macro.lower)}–${pct(result.macro.upper)}.`, '', `Top-relation row coverage: ${result.metadata.top_relation_rows}/${result.metadata.corpus_sentences}; coverage is not recall. Total expressed relations/facts in the saved world: ${result.metadata.total_expressed_relations}/${result.metadata.total_expressed_facts}. Human overrides used: ${c.human_overrides}.`,'','| Rank | Full dictionary, every fact and evaluation | Predicate ID | S | E | A | N | Precision endpoints |','|---:|---|---|---:|---:|---:|---:|---|',...result.strata.map(s=>`| ${s.rank} | [${esc(s.label)} (${s.relation})](reports/${s.relation}.md) | ${s.predicate_id} | ${s.S} | ${s.E} | ${s.A} | ${s.N} | ${pct(s.lower)}–${pct(s.upper)} |`),'','## Questions for human review','',...result.facts.filter(f=>f.judgment==='ambiguous').map(f=>`- [${f.case_id}](reports/${f.relation}.md#${f.case_id}): ${f.reviewer_question}`),''];
 fs.writeFileSync(path.join(absolute,'assessment.md'),md.join('\n'));return result;
}
export function compareAll({manifestFile=path.join(ROOT,'census_manifest.json'),options={}}={}){
 const manifest=json(manifestFile);assert(manifest.audits.length);const ids=new Set();for(const a of manifest.audits){assert(!ids.has(a.audit_id),'Duplicate audit in manifest');ids.add(a.audit_id);}
 const checked=manifest.audits.map(a=>({a,result:validateAudit(path.join(ROOT,a.folder),options)}));
 const comparisons=checked.map(({a,result:r})=>({audit_id:a.audit_id,label:a.label,source_sha256:r.metadata.source_sha256,...r.counts,...r.precision,macro:r.macro,total_expressed_relations:r.metadata.total_expressed_relations,total_expressed_facts:r.metadata.total_expressed_facts,top_relation_rows:r.metadata.top_relation_rows,corpus_sentences:r.metadata.corpus_sentences,assessment:path.join(a.folder,'assessment.md')}));
 for(const {a}of checked)writeAuditReport(path.join(ROOT,a.folder),options);
 const output={complete:true,unit:'Exact per-run top-20 expressed latent fact census; runs not pooled',runs:comparisons};fs.writeFileSync(path.join(ROOT,'comparison.json'),fmt(output));
 fs.writeFileSync(path.join(ROOT,'comparison.md'),['# Complete NYT census comparison','','[Method](METHOD.md) · [Machine-readable comparison](comparison.json) · [Prior evaluation comparison](prior_comparison.md) · [Changed judgments](judgment_changes.md)','','Every reported run passed full-census validation. S/N and (S+A)/N are exact descriptive fractions under the declared judgments, not confidence intervals. Separate runs are not pooled; these fractions do not measure gold recall or reviewer uncertainty.','','| Run | S | E | A | N | S/N | (S+A)/N | Top-20 rows |','|---|---:|---:|---:|---:|---:|---:|---:|',...comparisons.map(c=>`| [${esc(c.label)}](${c.assessment}) | ${c.S} | ${c.E} | ${c.A} | ${c.N} | ${pct(c.lower)} | ${pct(c.upper)} | ${c.top_relation_rows}/${c.corpus_sentences} |`),''].join('\n'));writePriorComparisons(checked);return output;
}
export function progress(){
 const rows=json(path.join(ROOT,'census_manifest.json')).audits.map(a=>{const d=json(path.join(ROOT,a.folder,'cases.json'));let confirmed=0,provisional=0,blank=0;for(const r of d.relations){const f=json(path.join(ROOT,a.folder,'annotations',r.relation+'.json'));for(const c of f.facts){if(!c.judgment)blank++;else if(c.provisional===true)provisional++;else confirmed++;}}return {audit_id:a.audit_id,label:a.label,N:d.metadata.population_facts,confirmed,provisional,blank};});
 const d={warning:'Workflow counts only; not validated census precision.',runs:rows};fs.writeFileSync(path.join(ROOT,'progress.json'),fmt(d));return d;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){
 const args=process.argv.slice(2);if(args[0]==='--progress')console.log(fmt(progress()));else if(args.length){for(const p of args){const r=writeAuditReport(p);console.log(JSON.stringify({audit_id:r.metadata.audit_id,...r.counts,...r.precision}));}}else console.log(fmt(compareAll()));
}
