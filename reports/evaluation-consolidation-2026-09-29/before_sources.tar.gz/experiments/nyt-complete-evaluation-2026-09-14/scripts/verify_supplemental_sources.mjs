import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {ROOT,REPO,json,sha,fmt} from './census_lib.mjs';
const out=path.join(ROOT,'supplemental');
const a=json(path.join(out,'archive250_provenance.json'));
const archive=fs.readFileSync(path.join(REPO,a.original),'utf8');assert.equal(sha(archive),a.archive_sha256);
const archiveLines=archive.split(/\r?\n/),converted=fs.readFileSync(path.join(out,'archive250_map.tsv'),'utf8').trimEnd().split(/\r?\n/);
assert.equal(a.line_map.length,250);assert.equal(converted.length,251);
assert.equal(archiveLines.filter(l=>l.trimStart().startsWith('Sentence [')).length,a.line_map.length);
for(const m of a.line_map){const [rel,e1,e2,arg1,arg2,trig]=converted[m.tsv_line-1].split('\t');
 assert.equal(archiveLines[m.archive_line-1].trim(),`Sentence [origin=Fact[${e1}, ${e2}, Rel[${rel}]], arg1=${arg1}, arg2=${arg2}, trig=Trig[${trig}]]`);
}
const result={verified_at:new Date().toISOString(),complete:true,archive250_rows:250,method:'Independently compare every converted archive250 TSV row to the exact source line; verify source hash; assert no eligible source line was omitted.'};
fs.writeFileSync(path.join(out,'source_verification.json'),fmt(result));console.log(fmt(result));
