import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {ROOT,json,fmt} from './census_lib.mjs';
import {validateAudit} from './report_censuses.mjs';
const main=json(path.join(ROOT,'census_manifest.json')).audits;
const supplemental=['audit_archive250'].map(audit_id=>({audit_id,folder:'supplemental/'+audit_id}));
const outputs=[];
for(const a of [...main,...supplemental]){
 const folder=path.join(ROOT,a.folder),expected=validateAudit(folder),saved=json(path.join(folder,'assessment.json'));
 assert.equal(JSON.stringify(saved)===JSON.stringify(expected),true,`Stale structured assessment: ${a.audit_id}`);
 const cases=json(path.join(folder,'cases.json'));
 const reportFiles=fs.readdirSync(path.join(folder,'reports')).filter(f=>f.endsWith('.md')).sort();
 assert.deepEqual(reportFiles,cases.relations.map(r=>r.relation+'.md').sort());
 let headings=0,evidenceRows=0;
 for(const r of cases.relations){const md=fs.readFileSync(path.join(folder,'reports',r.relation+'.md'),'utf8');
  const ids=[...md.matchAll(/^### (rel_\d+__ent_\d+__ent_\d+)$/gm)].map(m=>m[1]);
  assert.deepEqual(ids,r.facts.map(f=>f.case_id),`Missing/repeated/reordered printed facts: ${a.audit_id}/${r.relation}`);
  assert.equal([...md.matchAll(/^\*\*Judgment: (supported|incorrect|ambiguous)\*\*/gm)].length,r.facts.length);
  const lines=[...md.matchAll(/^\| \[(\d+)\]\(/gm)].map(m=>Number(m[1])).sort((a,b)=>a-b);
  const expectedLines=r.facts.flatMap(f=>f.source_lines).sort((a,b)=>a-b);
  assert.deepEqual(lines,expectedLines,`Missing printed evidence: ${a.audit_id}/${r.relation}`);
  headings+=ids.length;evidenceRows+=lines.length;
 }
 assert.equal(headings,expected.counts.N);assert.equal(evidenceRows,expected.metadata.top_relation_rows);
 outputs.push({audit_id:a.audit_id,printed_facts:headings,printed_evidence_rows:evidenceRows,complete:true});
}
const comparison=json(path.join(ROOT,'comparison.json'));assert.equal(comparison.runs.length,main.length);
for(const a of main){const row=comparison.runs.find(r=>r.audit_id===a.audit_id),assessment=json(path.join(ROOT,a.folder,'assessment.json'));assert(row);
 for(const k of ['N','S','E','A'])assert.equal(row[k],assessment.counts[k],`Stale comparison count ${a.audit_id}/${k}`);
 for(const k of ['lower','upper'])assert.equal(row[k],assessment.precision[k]);
}
const result={verified_at:new Date().toISOString(),complete:true,main_facts:outputs.slice(0,main.length).reduce((s,r)=>s+r.printed_facts,0),supplemental_facts:outputs.slice(main.length).reduce((s,r)=>s+r.printed_facts,0),method:'Revalidate source/annotations independently of saved assessments; compare every printed case heading, judgment count and evidence line against structured population; check all comparison counts.',audits:outputs};
fs.writeFileSync(path.join(ROOT,'analysis/report_artifact_verification.json'),fmt(result));console.log(fmt(result));
