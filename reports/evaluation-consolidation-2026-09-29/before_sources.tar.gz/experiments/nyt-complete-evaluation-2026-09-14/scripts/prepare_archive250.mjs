import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {ROOT,REPO,sha,fmt,stable,prepareCensus} from './census_lib.mjs';
const original='resources/sampler-140626/test/Entity_resolution_Relation/all-poss-facts/output-250/map_world.txt';
const raw=fs.readFileSync(path.join(REPO,original),'utf8');
const rows=[],lineMap=[];
for(const [i,line]of raw.split(/\r?\n/).entries()){
 if(!line.trimStart().startsWith('Sentence ['))continue;
 const m=line.match(/^\s*Sentence \[origin=Fact\[(Ent\[ent_\d+\]), (Ent\[ent_\d+\]), Rel\[(rel_\d+)\]\], arg1=(.*?), arg2=(.*?), trig=Trig\[(.*)\]\]$/);
 assert(m,`Cannot parse archive line ${i+1}`);assert(!m.slice(1).some(x=>x.includes('\t')));
 rows.push([m[3],m[1],m[2],m[4],m[5],m[6]].join('\t'));lineMap.push({tsv_line:rows.length+1,archive_line:i+1});
}
assert.equal(rows.length,250);
const out=path.join(ROOT,'supplemental');fs.mkdirSync(out,{recursive:true});
const input=path.join(out,'archive250_map.tsv');stable(input,'relation\tentity1\tentity2\targ1\targ2\tpath\n'+rows.join('\n')+'\n');
stable(path.join(out,'archive250_provenance.json'),fmt({original,archive_sha256:sha(raw),conversion:'Every displayed Sentence line, in archive order; no invented or supplemented evidence.',rows:250,full_source:'resources/sampler-140626/data/06-19/pluieTriples-1.json',different_corpus:true,main_comparison:false,line_map:lineMap}));
const entry=prepareCensus({source:input,audit_id:'audit_archive250',top_relations:20,label:'Archived 250-row MAP — different corpus'},{outRoot:out});
assert.equal(entry.population_facts,223);assert.equal(entry.relations,15);console.log(fmt(entry));
