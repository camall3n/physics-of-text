import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {ROOT,REPO,json,fmt,prepareCensus,assertRetainedEvaluation} from './census_lib.mjs';
// The retained manifest is the roster. Historical unblinding files also include
// retired runs and must never repopulate the current evaluation.
export function initialEntries(){
 return json(path.join(ROOT,'census_manifest.json')).audits.map(a=>({
  source:path.join(REPO,a.source),prior:a.prior_directory?path.join(REPO,a.prior_directory):undefined,audit_id:a.audit_id,label:a.label
 }));
}
export function prepareAll(entries){
 // Validate the whole batch before any retained entry can write artifacts.
 for(const entry of entries)assertRetainedEvaluation(entry);
 const file=path.join(ROOT,'census_manifest.json');const manifest=fs.existsSync(file)?json(file):{schema_version:1,unit:'Every expressed latent fact in each run\'s top 20 relations by assigned row count',audits:[]};
 for(const entry of entries){const result=prepareCensus(entry);const old=manifest.audits.find(a=>a.audit_id===result.audit_id);if(old&&JSON.stringify(old)!==JSON.stringify(result))throw Error('Changed census manifest entry');if(!old)manifest.audits.push(result);console.log(JSON.stringify(result));}
 manifest.audits.sort((a,b)=>a.label.localeCompare(b.label));fs.writeFileSync(file,fmt(manifest));return manifest;
}
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){const arg=process.argv[2];prepareAll(arg?json(path.resolve(arg)):initialEntries());}
