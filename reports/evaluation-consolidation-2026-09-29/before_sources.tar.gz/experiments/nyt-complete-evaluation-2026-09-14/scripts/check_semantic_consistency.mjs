// Diagnostic only. This script never assigns or modifies semantic judgments.
import fs from 'node:fs';
import path from 'node:path';
import {ROOT,json,fmt,sha} from './census_lib.mjs';
const groups=new Map();let reviewed=0,unreviewed=0;
for(const a of json(path.join(ROOT,'census_manifest.json')).audits){
 const dir=path.join(ROOT,a.folder),cases=json(path.join(dir,'cases.json'));
 for(const r of cases.relations){
  const ann=json(path.join(dir,'annotations',r.relation+'.json'));
  const labels=new Map(ann.facts.map(f=>[f.case_id,f]));
  for(const c of r.facts){const f=labels.get(c.case_id);
   if(!f?.judgment||f.provisional){unreviewed++;continue;}reviewed++;
   // Duplicate observations and numeric run-local IDs do not change the local
   // evidence meaning. Equality of the two argument IDs DOES change identity.
   const evidence=[...new Set(c.evidence.map(e=>JSON.stringify([e.arg1,e.arg2,e.dependency_path])))].sort();
   const signature=JSON.stringify([ann.predicate_id,c.entity1===c.entity2,evidence]);
   if(!groups.has(signature))groups.set(signature,[]);
   groups.get(signature).push({audit:a.audit_id,relation:r.relation,case_id:c.case_id,judgment:f.judgment,reason:f.reason,evidence_lines:f.evidence_lines});
  }
 }
}
const disagreements=[];let repeated=0;
for(const [signature,cases] of groups){if(cases.length>1)repeated++;if(new Set(cases.map(c=>c.judgment)).size<2)continue;
 const [predicate_id,self_entity,evidence]=JSON.parse(signature);
 disagreements.push({signature_sha256:sha(signature),predicate_id,self_entity,evidence:evidence.map(JSON.parse),cases});
}
const report={method:'Compare complete local literal evidence sets, shared predicate ID, and argument-ID equality. Ignore duplicate rows and run-local numeric IDs. Flag only; manual adjudication required. Primary annotations only; user overrides remain independent.',reviewed,unreviewed,distinct_signatures:groups.size,repeated_signatures:repeated,disagreement_count:disagreements.length,disagreements};
fs.writeFileSync(path.join(ROOT,'analysis','semantic_consistency.json'),fmt(report));
console.log(JSON.stringify({reviewed,unreviewed,repeated,disagreements:disagreements.length}));
