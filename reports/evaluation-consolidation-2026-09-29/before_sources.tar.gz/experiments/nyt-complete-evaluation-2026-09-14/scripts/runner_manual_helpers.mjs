// Recording helpers only: callers supply explicit, manually reviewed case indices.
// No keywords, probabilities, or evidence-based classifier assign a judgment.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const hash=x=>crypto.createHash('sha256').update(x).digest('hex');
export const seq=(a,b)=>Array.from({length:b-a+1},(_,i)=>a+i);
export function record(audit,relation,groups,{mixed=[],broad=[]}={}){
  const folder=path.join(root,'census',audit),caseRaw=fs.readFileSync(path.join(folder,'cases.json'));
  const r=JSON.parse(caseRaw).relations.find(r=>r.relation===relation);assert(r);
  const file=path.join(folder,'annotations',relation+'.json'),annotation=JSON.parse(fs.readFileSync(file));
  const entries=new Map();
  for(const [indices,judgment,reason,tags=[],question=''] of groups)for(const i of indices){
    assert(Number.isInteger(i)&&i>=0&&i<r.facts.length,`Bad index ${i}`);assert(!entries.has(i),`Repeated ${i}`);
    assert(['supported','incorrect','ambiguous'].includes(judgment));assert(reason);assert(judgment!=='ambiguous'||question);
    const c=r.facts[i],old=annotation.facts.find(f=>f.case_id===c.case_id);assert(old);
    const issue_tags=[...new Set([...tags,...(mixed.includes(i)?['mixed_evidence']:[]),...(broad.includes(i)?['broad_predicate']:[])])];
    entries.set(i,{...old,judgment,reason:`${c.names.map(n=>n.value).join('; ')}: ${reason}`,evidence_lines:c.source_lines,issue_tags,reviewer_question:question,provisional:false,review:{reviewer:'runner',method:'Explicit manual judgment after reading the full relation dictionary and every supplied case row; citations include the complete considered evidence.',reviewed_at:new Date().toISOString()}});
  }
  assert.equal(entries.size,r.facts.length,'Manual record must explicitly cover every case');
  annotation.facts=r.facts.map((_,i)=>entries.get(i));
  fs.writeFileSync(file,JSON.stringify(annotation,null,2)+'\n');
  const logdir=path.join(root,'analysis','manual_records');fs.mkdirSync(logdir,{recursive:true});
  fs.writeFileSync(path.join(logdir,audit+'__'+relation+'.json'),JSON.stringify({audit,relation,cases_sha256:hash(caseRaw),reviewer:'runner',complete_dictionary_read:true,complete_case_evidence_read:true,groups:groups.map(g=>({indices:g[0],case_ids:g[0].map(i=>r.facts[i].case_id),judgment:g[1],reason:g[2],tags:g[3]??[],question:g[4]??''})),mixed,broad},null,2)+'\n');
  console.log(`${audit}/${relation}: ${annotation.facts.length} complete manual judgments`);
}
