import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';

const scriptPath = fileURLToPath(import.meta.url);
const experiment = path.resolve(path.dirname(scriptPath), '..');
export const SALT = 'nyt-precision-screen-2026-09-12-v1';
const hash = value => crypto.createHash('sha256').update(value).digest('hex');
const add = (map,key,value=1) => map.set(key,(map.get(key)??0)+value);
const ordered = map => [...map].map(([value,count])=>({value,count})).sort((a,b)=>b.count-a.count||a.value.localeCompare(b.value));
const relationNumber = id => Number(id.replace(/^rel_/,''));
const escape = s => String(s).replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('|','\\|');

export function parseMap(raw) {
  const lines = raw.trimEnd().split(/\r?\n/);
  assert.equal(lines[0], 'relation\tentity1\tentity2\targ1\targ2\tpath', 'Unexpected MAP header');
  const facts = new Map(), relations = new Map();
  for(let i=1;i<lines.length;i++) {
    const fields=lines[i].split('\t');
    assert.equal(fields.length,6,`Line ${i+1} is not a six-column TSV row`);
    const [relation,entity1,entity2,arg1,arg2,dependency_path]=fields;
    assert(/^rel_\d+$/.test(relation));
    assert(/^Ent\[ent_\d+\]$/.test(entity1)&&/^Ent\[ent_\d+\]$/.test(entity2));
    const id=[relation,entity1.slice(4,-1),entity2.slice(4,-1)].join('__');
    if(!facts.has(id)) facts.set(id,{case_id:id,relation,entity1,entity2,first_line:i+1,evidence:[],names:new Map(),paths:new Map()});
    const fact=facts.get(id);
    fact.evidence.push({line:i+1,relation,entity1,entity2,arg1,arg2,dependency_path,original_row:lines[i]});
    add(fact.names,`${arg1} → ${arg2}`);add(fact.paths,dependency_path);
    if(!relations.has(relation)) relations.set(relation,{relation,sentence_count:0,facts:[],paths:new Map()});
    const r=relations.get(relation);r.sentence_count++;add(r.paths,dependency_path);
  }
  for(const c of facts.values()) {
    c.sentence_count=c.evidence.length;
    c.names=ordered(c.names);c.paths=ordered(c.paths);
    c.source_lines=c.evidence.map(e=>e.line);
    relations.get(c.relation).facts.push(c);
  }
  const ranked=[...relations.values()].sort((a,b)=>b.sentence_count-a.sentence_count||relationNumber(a.relation)-relationNumber(b.relation));
  ranked.forEach((r,i)=>{
    r.rank=i+1;r.paths=ordered(r.paths);
    r.facts.sort((a,b)=>b.sentence_count-a.sentence_count||a.first_line-b.first_line);
    r.facts.forEach((c,j)=>{c.relation_rank=r.rank;c.fact_rank_by_rows=j+1;});
  });
  assert.equal([...facts.values()].reduce((n,c)=>n+c.sentence_count,0),lines.length-1);
  return {sentence_count:lines.length-1,fact_count:facts.size,relation_count:ranked.length,relations:ranked};
}

export function selectReview(raw, {perRelation=5,topRelations=20}={}) {
  const parsed=parseMap(raw),source_sha256=hash(raw);
  const top=parsed.relations.slice(0,topRelations);
  const population_size=top.reduce((n,r)=>n+r.facts.length,0);
  const selected=top.map(r=>{
    const candidates=r.facts.map(c=>({...c,selection_hash:hash([SALT,source_sha256,c.relation,c.entity1,c.entity2,c.first_line].join('\0'))}));
    candidates.sort((a,b)=>a.selection_hash.localeCompare(b.selection_hash)||a.case_id.localeCompare(b.case_id));
    const sample=candidates.slice(0,perRelation);
    return {relation:r.relation,rank:r.rank,sentence_count:r.sentence_count,population_facts:r.facts.length,
      sample_facts:sample.length,micro_weight:r.facts.length/population_size,macro_weight:1/top.length,
      selection_fraction:sample.length/r.facts.length,paths:r.paths,facts:sample};
  });
  assert(Math.abs(selected.reduce((n,r)=>n+r.micro_weight,0)-1)<1e-12);
  return {metadata:{source_sha256,selection_salt:SALT,selection:'Lowest SHA256(salt, source hash, relation, ordered entity IDs, first source line), all separated by NUL',
    corpus_sentences:parsed.sentence_count,total_expressed_relations:parsed.relation_count,total_expressed_facts:parsed.fact_count,
    top_relations:top.length,per_relation_requested:perRelation,population_facts:population_size,
    sampled_facts:selected.reduce((n,r)=>n+r.sample_facts,0),unit:'Expressed ordered latent fact',
    ranking:'Descending assigned rows; numeric relation ID breaks ties',
    primary_estimator:'sum_r(population_facts_r / population_facts_all * supported_r / sample_facts_r)',
    ambiguity_estimator:'same weights, with (supported_r + ambiguous_r) / sample_facts_r',
    annotations:'Manual only. Do not transfer labels by relation ID or infer them using keywords.'},relations:selected};
}

function writeStable(file,content) {
  if(fs.existsSync(file)) {
    assert.equal(fs.readFileSync(file,'utf8'),content,`Refusing to overwrite changed review artifact ${file}`);
  } else fs.writeFileSync(file,content);
}
function evidenceMarkdown(c) {
  return [`### ${c.case_id}`, '', `**Observed names:** ${c.names.map(n=>`${escape(n.value)} (${n.count})`).join('; ')}`, '',
    `Ordered IDs: ${c.entity1} → ${c.entity2}. Assigned rows: ${c.sentence_count}.`, '',
    '| Source line | Literal first argument | Literal second argument | Full dependency path |','|---:|---|---|---|',
    ...c.evidence.map(e=>`| [${e.line}](../raw_map.tsv:${e.line}) | ${escape(e.arg1)} | ${escape(e.arg2)} | ${escape(e.dependency_path)} |`),''];
}

export function prepareRun(runPath) {
  const absolute=path.resolve(runPath);
  assert(absolute.startsWith(experiment+path.sep),'Run must be inside this isolated investigation');
  const candidate=fs.statSync(absolute).isDirectory()?path.join(absolute,'map_world_sentences.tsv'):absolute;
  const source=fs.existsSync(candidate)?candidate:path.join(absolute,'output/map_world_sentences.tsv');
  assert(fs.existsSync(source),`MAP file missing for ${runPath}`);
  const runDirectory=fs.statSync(absolute).isDirectory()?absolute:path.dirname(absolute);
  const runManifest=JSON.parse(fs.readFileSync(path.join(runDirectory,'run.json'),'utf8'));
  assert(['completed','complete'].includes(runManifest.status),`Refusing to sample a run whose manifest status is ${runManifest.status}`);
  const raw=fs.readFileSync(source,'utf8'),review=selectReview(raw);
  const auditId='audit_'+hash(path.relative(experiment,source)+'\0'+review.metadata.source_sha256).slice(0,10);
  const root=path.join(experiment,'manual_review'),out=path.join(root,auditId);
  fs.mkdirSync(path.join(out,'relations'),{recursive:true});fs.mkdirSync(path.join(out,'annotations'),{recursive:true});
  const protocol=path.join(experiment,'analysis/manual_protocol.md');
  review.metadata.audit_id=auditId;
  review.metadata.protocol_sha256=hash(fs.readFileSync(protocol));
  review.metadata.copied_source='raw_map.tsv';
  writeStable(path.join(out,'raw_map.tsv'),raw);
  writeStable(path.join(out,'cases.json'),JSON.stringify(review,null,2)+'\n');
  for(const r of review.relations) {
    const md=[`# ${auditId} — ${r.relation}`, '',
      `Relation rank ${r.rank}; ${r.sentence_count} assigned rows; **${r.population_facts} expressed facts; ${r.sample_facts} sampled**. Micro weight: ${r.micro_weight.toFixed(10)}.`, '',
      '**Choose and record a directional predicate from the dictionary before grading the five sampled facts.** Keep competing meanings visible. See [protocol](../../../analysis/manual_protocol.md).', '',
      '## Complete dependency-path dictionary', '', '| Count | Dependency path |','|---:|---|',
      ...r.paths.map(p=>`| ${p.count} | ${escape(p.value)} |`),'',
      '## Selected facts, in fixed random order', '',...r.facts.flatMap(evidenceMarkdown)];
    writeStable(path.join(out,'relations',r.relation+'.md'),md.join('\n'));
    const annotations={relation:r.relation,label:'',definition:'',scope_notes:'',
      facts:r.facts.map(c=>({case_id:c.case_id,judgment:'',reason:'',evidence_lines:[],issue_tags:[],reviewer_question:''}))};
    const annotationFile=path.join(out,'annotations',r.relation+'.json');
    if(!fs.existsSync(annotationFile))fs.writeFileSync(annotationFile,JSON.stringify(annotations,null,2)+'\n');
  }
  const index=[`# Manual screening sample ${auditId}`, '',
    `[Protocol](../../analysis/manual_protocol.md) · [Complete structured evidence](cases.json) · [Copied original MAP rows](raw_map.tsv)`, '',
    `Sample: **${review.metadata.sampled_facts} facts from ${review.metadata.top_relations} relations**, population ${review.metadata.population_facts} expressed facts. Every selected case is unjudged at extraction. Configuration names are held in the separate unblinding manifest.`, '',
    'The primary estimator weights each relation by its complete fact count. The raw fraction of supported sample cases is a macro-like estimate under equal allocation; it is not automatically micro precision. Keep ambiguous cases in the denominator. Five cases per stratum provide limited statistical precision.', '',
    '| Rank | Relation evidence | Population facts | Sample | Micro weight | Annotation file |','|---:|---|---:|---:|---:|---|',
    ...review.relations.map(r=>`| ${r.rank} | [${r.relation}](relations/${r.relation}.md) | ${r.population_facts} | ${r.sample_facts} | ${r.micro_weight.toFixed(6)} | [JSON](annotations/${r.relation}.json) |`),''];
  writeStable(path.join(out,'README.md'),index.join('\n'));
  const manifestFile=path.join(root,'unblinding.json');
  const manifest=fs.existsSync(manifestFile)?JSON.parse(fs.readFileSync(manifestFile,'utf8')):{warning:'Contains variant/run identities. Keep outside the manual grading workflow where feasible.',audits:[]};
  const entry={audit_id:auditId,source:path.relative(experiment,source),source_sha256:review.metadata.source_sha256,
    protocol_sha256:review.metadata.protocol_sha256,population_facts:review.metadata.population_facts,sampled_facts:review.metadata.sampled_facts};
  const previous=manifest.audits.find(a=>a.audit_id===auditId);
  if(previous) assert.deepEqual(previous,entry);else manifest.audits.push(entry);
  manifest.audits.sort((a,b)=>a.audit_id.localeCompare(b.audit_id));
  fs.writeFileSync(manifestFile,JSON.stringify(manifest,null,2)+'\n');
  return {audit_id:auditId,folder:path.relative(experiment,out),sampled_facts:review.metadata.sampled_facts,population_facts:review.metadata.population_facts};
}

if(process.argv[1]&&path.resolve(process.argv[1])===scriptPath) {
  const runs=process.argv.slice(2);
  if(!runs.length)throw new Error('Usage: node scripts/prepare_manual_samples.mjs RUN_DIR [RUN_DIR ...]');
  for(const run of runs)console.log(JSON.stringify(prepareRun(run)));
}
