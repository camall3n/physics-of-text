import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';

const scriptPath=fileURLToPath(import.meta.url);
const experiment=path.resolve(path.dirname(scriptPath),'..');
const sha256=x=>crypto.createHash('sha256').update(x).digest('hex');
const sum=xs=>xs.reduce((a,b)=>a+b,0);
function logChoose(n,k) {
  if(k<0||k>n)return -Infinity;
  k=Math.min(k,n-k);let value=0;
  for(let i=1;i<=k;i++)value+=Math.log(n-k+i)-Math.log(i);
  return value;
}
function tail(N,K,n,k,upper) {
  let probability=0;
  for(let x=Math.max(0,n-(N-K));x<=Math.min(n,K);x++)
    if(upper?x>=k:x<=k)probability+=Math.exp(logChoose(K,x)+logChoose(N-K,n-x)-logChoose(N,n));
  return probability;
}

// Invert hypergeometric tails for a finite population, counting inclusive tails.
// tailAlpha is the error allocated to EACH of the lower/upper one-sided bounds.
export function finitePopulationBounds(N,n,k,tailAlpha=.025) {
  assert(Number.isInteger(N)&&Number.isInteger(n)&&Number.isInteger(k)&&0<n&&n<=N&&0<=k&&k<=n);
  assert(tailAlpha>0&&tailAlpha<.5);
  let lower=k,upper=N-n+k;
  for(let K=k;K<=N-n+k;K++)if(tail(N,K,n,k,true)>=tailAlpha){lower=K;break;}
  for(let K=N-n+k;K>=k;K--)if(tail(N,K,n,k,false)>=tailAlpha){upper=K;break;}
  return {lower_count:lower,upper_count:upper,lower:lower/N,upper:upper/N};
}

export function summarizeStrata(strata) {
  const H=strata.length,N=sum(strata.map(s=>s.population_facts));
  assert(H>0&&N>0);
  const tailAlpha=.05/(2*H);
  const rs=strata.map(s=>{
    const {population_facts:Nr,sample_facts:n,supported:S,incorrect:E,ambiguous:A}=s;
    assert.equal(S+E+A,n);assert(n<=Nr);
    const lower=S/n,upper=(S+A)/n,w=Nr/N;
    const variance=p=>n===Nr?0:(n<=1?null:w*w*(1-n/Nr)*p*(1-p)/(n-1));
    return {...s,micro_weight:w,macro_weight:1/H,lower,upper,
      lower_variance_component:variance(lower),upper_variance_component:variance(upper),
      strict_population_bounds:finitePopulationBounds(Nr,n,S,tailAlpha),
      optimistic_population_bounds:finitePopulationBounds(Nr,n,S+A,tailAlpha)};
  });
  const variance=key=>rs.some(r=>r[key]===null)?null:sum(rs.map(r=>r[key]));
  const lowVar=variance('lower_variance_component'),upVar=variance('upper_variance_component');
  return {population_facts:N,sampled_facts:sum(rs.map(r=>r.sample_facts)),relations:H,
    sample_counts:{supported:sum(rs.map(r=>r.supported)),incorrect:sum(rs.map(r=>r.incorrect)),ambiguous:sum(rs.map(r=>r.ambiguous))},
    micro:{lower:sum(rs.map(r=>r.micro_weight*r.lower)),upper:sum(rs.map(r=>r.micro_weight*r.upper))},
    macro:{lower:sum(rs.map(r=>r.lower))/H,upper:sum(rs.map(r=>r.upper))/H},
    exploratory_design_se:{lower:lowVar===null?null:Math.sqrt(lowVar),upper:upVar===null?null:Math.sqrt(upVar),
      limitation:'Plug-in finite-population stratified SE; n=5 strata can yield zero sample variance despite genuine uncertainty. Do not construct a Wald CI from this alone.'},
    conservative_sampling_bounds:{confidence:.95,tail_alpha_per_stratum_bound:tailAlpha,
      strict_lower:sum(rs.map(r=>r.micro_weight*r.strict_population_bounds.lower)),
      strict_upper:sum(rs.map(r=>r.micro_weight*r.strict_population_bounds.upper)),
      optimistic_lower:sum(rs.map(r=>r.micro_weight*r.optimistic_population_bounds.lower)),
      optimistic_upper:sum(rs.map(r=>r.micro_weight*r.optimistic_population_bounds.upper)),
      explanation:'Finite-population hypergeometric inversion; each endpoint interval uses Bonferroni across 20 strata. The strict lower and optimistic upper together also give a conservative 95% envelope covering sampling uncertainty plus ambiguity endpoints. Wide bounds are intentional. Coverage concerns the random sample of this saved run, conditional on fixed case judgments, not run-to-run randomness or reviewer validity.'},
    strata:rs};
}

export function reportAudit(folder) {
  const absolute=path.resolve(folder);
  assert(absolute.startsWith(path.join(experiment,'manual_review')+path.sep),'Audit must be inside this investigation manual_review folder');
  const casesFile=path.join(absolute,'cases.json'),rawFile=path.join(absolute,'raw_map.tsv');
  const cases=JSON.parse(fs.readFileSync(casesFile,'utf8'));
  assert.equal(sha256(fs.readFileSync(rawFile)),cases.metadata.source_sha256,'Copied MAP changed since selection');
  assert.equal(sha256(fs.readFileSync(path.join(experiment,'analysis/manual_protocol.md'))),cases.metadata.protocol_sha256,'Protocol changed since selection; review amendment explicitly before resuming');
  const judgments=[],strata=[];
  for(const relation of cases.relations) {
    const annotationFile=path.join(absolute,'annotations',relation.relation+'.json');
    const a=JSON.parse(fs.readFileSync(annotationFile,'utf8'));
    assert.equal(a.relation,relation.relation);
    for(const key of ['label','definition','scope_notes'])assert(typeof a[key]==='string'&&a[key].trim().length>0,`${a.relation}: missing ${key}`);
    assert.equal(a.facts.length,relation.sample_facts,`${a.relation}: wrong number of annotation cases`);
    assert.equal(new Set(a.facts.map(c=>c.case_id)).size,a.facts.length,`${a.relation}: duplicate judgments`);
    const selected=new Map(relation.facts.map(c=>[c.case_id,c]));
    const counts={supported:0,incorrect:0,ambiguous:0};
    for(const j of a.facts) {
      const c=selected.get(j.case_id);assert(c,`Unselected case ${j.case_id}`);
      assert(['supported','incorrect','ambiguous'].includes(j.judgment),`${j.case_id}: judgment missing/invalid`);
      assert(typeof j.reason==='string'&&j.reason.trim().length>0,`${j.case_id}: reason missing`);
      assert(Array.isArray(j.evidence_lines)&&j.evidence_lines.length>0,`${j.case_id}: citations missing`);
      assert(j.evidence_lines.every(line=>Number.isInteger(line)&&c.source_lines.includes(line)),`${j.case_id}: cites a line outside its evidence`);
      assert(Array.isArray(j.issue_tags),`${j.case_id}: issue_tags must be an array`);
      if(j.judgment==='ambiguous')assert(typeof j.reviewer_question==='string'&&j.reviewer_question.trim().length>0,`${j.case_id}: ambiguity requires a reviewer question`);
      counts[j.judgment]++;
      judgments.push({...c,judgment:j.judgment,reason:j.reason,evidence_lines:j.evidence_lines,
        issue_tags:j.issue_tags,reviewer_question:j.reviewer_question??'',predicate:a.label,definition:a.definition});
    }
    strata.push({relation:relation.relation,rank:relation.rank,label:a.label,definition:a.definition,scope_notes:a.scope_notes,
      population_facts:relation.population_facts,sample_facts:relation.sample_facts,...counts});
  }
  assert.equal(judgments.length,cases.metadata.sampled_facts);
  const result={audit_id:cases.metadata.audit_id,source_sha256:cases.metadata.source_sha256,
    cases_sha256:sha256(fs.readFileSync(casesFile)),protocol_sha256:cases.metadata.protocol_sha256,
    ...summarizeStrata(strata),facts:judgments};
  const percent=n=>(100*n).toFixed(1)+'%',range=(l,u)=>`${percent(l)}–${percent(u)}`;
  const escape=s=>s.replaceAll('|','\\|').replaceAll('\n',' ');
  const lines=[`# Manual precision screen: ${result.audit_id}`,'',
    '[Sample index](README.md) · [Structured assessment](assessment.json) · [Review protocol](../../analysis/manual_protocol.md)','',
    `**Estimated micro precision: ${range(result.micro.lower,result.micro.upper)}**, counting ambiguous cases first as incorrect and then as supported. This is an ambiguity range of estimates, not a confidence interval.`, '',
    `Sample counts: ${result.sample_counts.supported} supported, ${result.sample_counts.incorrect} incorrect, ${result.sample_counts.ambiguous} ambiguous; ${result.sampled_facts} assessed out of ${result.population_facts} facts. The estimate weights each relation by its total fact population; raw sample counts are not the micro denominator.`, '',
    `Macro precision estimate: ${range(result.macro.lower,result.macro.upper)}.`, '',
    `Conservative 95% finite-population sampling interval for the strict endpoint: **${range(result.conservative_sampling_bounds.strict_lower,result.conservative_sampling_bounds.strict_upper)}**; for the optimistic endpoint: **${range(result.conservative_sampling_bounds.optimistic_lower,result.conservative_sampling_bounds.optimistic_upper)}**. The envelope ${range(result.conservative_sampling_bounds.strict_lower,result.conservative_sampling_bounds.optimistic_upper)} includes both sampling uncertainty and the two ambiguity treatments. These deliberately wide bounds use hypergeometric inversion per stratum and Bonferroni correction. They do not cover variation between sampler seeds or errors in manual judgment.`, '',
    `Exploratory plug-in design SE: ${result.exploratory_design_se.lower===null?'undefined':percent(result.exploratory_design_se.lower)} strict, ${result.exploratory_design_se.upper===null?'undefined':percent(result.exploratory_design_se.upper)} optimistic. With only five cases per relation this can understate uncertainty; no Wald confidence interval is claimed.`, '',
    '| Rank | Relation / chosen predicate | Population | Sample S/E/A | Micro weight | Sample support range |',
    '|---:|---|---:|---:|---:|---:|',
    ...result.strata.map(s=>`| ${s.rank} | [${s.relation}](relations/${s.relation}.md): ${escape(s.label)} | ${s.population_facts} | ${s.supported}/${s.incorrect}/${s.ambiguous} | ${s.micro_weight.toFixed(4)} | ${range(s.lower,s.upper)} |`),'',
    '## Ambiguous cases for inspection','',
    ...judgments.filter(c=>c.judgment==='ambiguous').flatMap(c=>[`- [${c.case_id}](relations/${c.relation}.md): ${c.reviewer_question}`]),'',
    'Every sampled case has a manual judgment, reason and citations restricted to its own evidence. The input MAP hash, unchanged protocol hash, exact case coverage and stratum weights were checked. Predicate definitions and scope notes are in the structured assessment and annotation files.',''];
  fs.writeFileSync(path.join(absolute,'assessment.json'),JSON.stringify(result,null,2)+'\n');
  fs.writeFileSync(path.join(absolute,'assessment.md'),lines.join('\n'));
  return {audit_id:result.audit_id,population_facts:result.population_facts,sampled_facts:result.sampled_facts,
    sample_counts:result.sample_counts,micro:result.micro,macro:result.macro,conservative_sampling_bounds:result.conservative_sampling_bounds};
}
if(process.argv[1]&&path.resolve(process.argv[1])===scriptPath) {
  if(process.argv.length<3)throw new Error('Usage: node scripts/report_manual_samples.mjs manual_review/AUDIT [AUDIT ...]');
  for(const folder of process.argv.slice(2))console.log(JSON.stringify(reportAudit(folder)));
}
